package com.example.internshops1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class bookassign extends AppCompatActivity {
    LibraryTbl libraryTbl;

    EditText nameET;
    EditText usnET;
    EditText bookborrowedss;
    EditText bookreturnss;
    Spinner sectionSpn;
    Spinner branchSpn;
    Spinner booknamess;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookassign);


        nameET = findViewById(R.id.nameET);
        usnET = findViewById(R.id.usnET);
        sectionSpn = findViewById(R.id.sectionSpn);
        branchSpn = findViewById(R.id.branchSpn);
        booknamess=findViewById(R.id.bookSpn);
        bookborrowedss=findViewById(R.id.bookET);
        bookreturnss=findViewById(R.id.bookreturn);

        Button b1=findViewById(R.id.submitBtn);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                String name = nameET.getText().toString();
                //  String branch = branchET.getText().toString();
                String usn = usnET.getText().toString();
               // String mobileNumber = mobileNumberET.getText().toString();
                // String section = sectionET.getText().toString();
                String section = sectionSpn.getSelectedItem().toString();
                String branch = branchSpn.getSelectedItem().toString();

                String booknames =booknamess.getSelectedItem().toString();

                String bookborr = bookborrowedss.getText().toString();

                String bookret = bookreturnss.getText().toString();

                //String bookret = bookreturn.getSelectedItem().toString();

                //String branch = branchSpn.getSelectedItem().toString();




                libraryTbl = new LibraryTbl();
                libraryTbl.name = name;
                libraryTbl.branch = branch;
                libraryTbl.usn = usn;
               // student.mobileNumber = mobileNumber;
                libraryTbl.section = section;
                libraryTbl.bookname=booknames;
                libraryTbl.bookborrowed=bookborr;
                libraryTbl.bookreturn=bookret;

                libraryTbl.addStudent(bookassign.this,libraryTbl);
                Toast.makeText(bookassign.this,"Book Assigned Successfully",Toast.LENGTH_SHORT).show();



                /*
                Intent intent = new Intent();
                intent.putExtra("student", student);
                startActivity(intent);
                */

                //in StudentDetailsActivity
                //Student student1 = (Student) getIntent().getSerializableExtra("student");


            }
        });



    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();
        if(id==R.id.logout)
        {
            Toast.makeText(this,"Logout Clicked",Toast.LENGTH_LONG).show();
        }
        else if(id==R.id.slists)
        {
            Intent intentss=new Intent(this,librarylist.class);
            startActivity(intentss);
        }


        return super.onOptionsItemSelected(item);
    }
}
