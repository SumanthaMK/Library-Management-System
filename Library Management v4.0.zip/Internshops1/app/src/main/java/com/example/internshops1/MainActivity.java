package com.example.internshops1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText usernameET, passwordET;
    Button loginBtn;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv=findViewById(R.id.tv);
        tv.setSelected(true);
        usernameET = findViewById(R.id.usernameET);
        passwordET = findViewById(R.id.passwordET);
        loginBtn = findViewById(R.id.loginBtn);

        loginBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                String username = usernameET.getText().toString();
                String password = passwordET.getText().toString();

                if (username.equalsIgnoreCase("admin")
                        && password.equalsIgnoreCase("123"))
                {
                    Toast.makeText(MainActivity.this,
                            "Login Successful",
                            Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(MainActivity.this,
                            bookassign.class);
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(MainActivity.this,
                            "Login Failed",
                            Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
