package com.example.internshops1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.Calendar;

public class bookassign extends AppCompatActivity {
    LibraryTbl libraryTbl;

    EditText nameET;
    EditText usnET;
    EditText bookborrowedss;
    EditText bookreturnss;
    Spinner sectionSpn;
    Spinner branchSpn;
    Spinner booknamess;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookassign);


        nameET = findViewById(R.id.nameET);
        usnET = findViewById(R.id.usnET);
        sectionSpn = findViewById(R.id.sectionSpn);
        branchSpn = findViewById(R.id.branchSpn);
        booknamess=findViewById(R.id.bookSpn);
        bookborrowedss=findViewById(R.id.bookET);
        bookreturnss=findViewById(R.id.bookreturn);

        Calendar calendar=Calendar.getInstance();
        final int year=calendar.get(Calendar.YEAR);
        final int month=calendar.get(Calendar.MONTH);
        final int day=calendar.get(Calendar.DAY_OF_MONTH);

        Button b1=findViewById(R.id.submitBtn);
        bookborrowedss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog=new DatePickerDialog(bookassign.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        month=month+1;
                        String date=day+"/"+month+"/"+year;
                        bookborrowedss.setText(date);
                        //bookborr=date;
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });



        bookreturnss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog=new DatePickerDialog(bookassign.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        month=month+1;
                        String dates=day+"/"+month+"/"+year;
                        bookreturnss.setText(dates);
                        //bookborr=date;
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (TextUtils.isEmpty(nameET.getText()))
                {
                    nameET.setError("Field Cannot be Empty");
                    nameET.requestFocus();
                }

                if (TextUtils.isEmpty(usnET.getText()))
                {
                    usnET.setError("Field Cannot be Empty");
                    usnET.requestFocus();
                }
                //  String branch = branchET.getText().toString();
                String name = nameET.getText().toString();

                String usn = usnET.getText().toString();
               // String mobileNumber = mobileNumberET.getText().toString();
                // String section = sectionET.getText().toString();
                String section = sectionSpn.getSelectedItem().toString();
                String branch = branchSpn.getSelectedItem().toString();

                String booknames =booknamess.getSelectedItem().toString();
                String bookborr=bookborrowedss.getText().toString();

             //  String bookborr = bookborrowedss.getText().toString();

                String bookret = bookreturnss.getText().toString();



                //String bookborr = bookborrowedss.getText().toString();

                //String bookret = bookreturn.getSelectedItem().toString();

                //String branch = branchSpn.getSelectedItem().toString();




                libraryTbl = new LibraryTbl();
                libraryTbl.name = name;
                libraryTbl.branch = branch;
                libraryTbl.usn = usn;
               // student.mobileNumber = mobileNumber;
                libraryTbl.section = section;
                libraryTbl.bookname=booknames;
                libraryTbl.bookborrowed=bookborr;
                libraryTbl.bookreturn=bookret;

                libraryTbl.addStudent(bookassign.this,libraryTbl);
                Toast.makeText(bookassign.this,"Book Assigned Successfully",Toast.LENGTH_SHORT).show();



                /*
                Intent intent = new Intent();
                intent.putExtra("student", student);
                startActivity(intent);
                */

                //in StudentDetailsActivity
                //Student student1 = (Student) getIntent().getSerializableExtra("student");


            }
        });



    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();
        if(id==R.id.logout)
        {
            Toast.makeText(this,"Logged Out",Toast.LENGTH_LONG).show();
            Intent intent=new Intent(this,MainActivity.class);
            startActivity(intent);
        }
        else if(id==R.id.slists)
        {
            Intent intentss=new Intent(this,librarylist.class);
            startActivity(intentss);
        }


        return super.onOptionsItemSelected(item);
    }
}
