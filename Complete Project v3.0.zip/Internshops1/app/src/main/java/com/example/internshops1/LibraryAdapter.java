package com.example.internshops1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class LibraryAdapter extends RecyclerView.Adapter<LibraryAdapter.libraryViewHolder>
{
    private final LayoutInflater mInflater;
    List<LibraryTbl> libraryTbls;
    Context context;

    public LibraryAdapter(Context mContext, List<LibraryTbl> mlibraryTbls)
    {
        context = mContext;
        mInflater = LayoutInflater.from(context);
        libraryTbls = mlibraryTbls;
    }


    class libraryViewHolder extends RecyclerView.ViewHolder
    {
        TextView libraryNameTV, usnTV, branchTV, sectionTV, booknames,bookborroweds,bookreturneds;
        CardView cardView;
        Button deleteButton;
        //ImageView deleteIV;

        public libraryViewHolder(@NonNull View itemView)
        {
            super(itemView);
            libraryNameTV = itemView.findViewById(R.id.namesTV);
            branchTV = itemView.findViewById(R.id.branchTV);
            sectionTV = itemView.findViewById(R.id.sectionTV);
            bookborroweds = itemView.findViewById(R.id.borrowedTV);
            bookreturneds=itemView.findViewById(R.id.returnTV);
            booknames=itemView.findViewById(R.id.bookTV);
            usnTV = itemView.findViewById(R.id.usnTV);
            cardView = itemView.findViewById(R.id.cardView);
            deleteButton=itemView.findViewById(R.id.btndlt);
            //deleteIV = itemView.findViewById(R.id.deleteIV);
        }
    }

    @NonNull
    @Override
    public LibraryAdapter.libraryViewHolder onCreateViewHolder(@NonNull ViewGroup parent,
                                                                   int viewType)
    {
        View mItemView = mInflater.inflate(R.layout.library_list_items,
                parent, false);
        return new libraryViewHolder(mItemView);
    }

    @Override
    public void onBindViewHolder(@NonNull libraryViewHolder holder, final int position)
    {
        final LibraryTbl libraryTbl = libraryTbls.get(position);
        holder.libraryNameTV.setText(libraryTbl.name);
        holder.usnTV.setText(libraryTbl.usn);
        holder.branchTV.setText(libraryTbl.branch);
        holder.sectionTV.setText(libraryTbl.section);
        holder.bookborroweds.setText(libraryTbl.bookborrowed);
        holder.bookreturneds.setText(libraryTbl.bookreturn);
        holder.booknames.setText(libraryTbl.bookname);

        holder.cardView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(context, libraryTbl.name + " clicked", Toast.LENGTH_SHORT).show();
              //  Toast.makeText(context, libraryTbl.name + "  Retruned The Book "+libraryTbl.bookname, Toast.LENGTH_LONG).show();
                //LibraryTbl.deleteStudent(view.getContext(),libraryTbl);
                //((librarylist)context).recreate();
            }
        });

        holder.deleteButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                //Toast.makeText(context, libraryTbl.name + " clicked", Toast.LENGTH_SHORT).show();
                Toast.makeText(context, libraryTbl.name + "  Retruned The Book "+libraryTbl.bookname, Toast.LENGTH_LONG).show();
                LibraryTbl.deleteStudent(view.getContext(),libraryTbl);
                ((librarylist)context).recreate();
            }
        });





//        holder.deleteIV.setOnClickListener(new View.OnClickListener()
//        {
//            @Override
//            public void onClick(View view)
//            {
//                LibraryTbl.deletebook(context, libraryTbl);
//                Toast.makeText(context, libraryTbl.name + " deleted", Toast.LENGTH_LONG).show();
//
//                ((librarylist) context).recreate();
//            }
//        });
    }

    @Override
    public int getItemCount()
    {
        return libraryTbls.size();
    }
}